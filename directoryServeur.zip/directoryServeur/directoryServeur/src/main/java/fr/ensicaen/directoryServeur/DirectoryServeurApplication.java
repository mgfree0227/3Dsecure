package fr.ensicaen.directoryServeur;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DirectoryServeurApplication {

	public static void main(String[] args) {
		SpringApplication.run(DirectoryServeurApplication.class, args);
	}

}
