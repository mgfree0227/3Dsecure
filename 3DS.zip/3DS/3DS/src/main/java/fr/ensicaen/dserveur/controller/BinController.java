package fr.ensicaen.dserveur.controller;

import fr.ensicaen.dserveur.entity.BIN;
import fr.ensicaen.dserveur.service.BinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("bin")
public class BinController {

    @Autowired
    private BinService service;

    @GetMapping("/")
    public List<BIN> list() {
        return service.getAll();
    }
}
