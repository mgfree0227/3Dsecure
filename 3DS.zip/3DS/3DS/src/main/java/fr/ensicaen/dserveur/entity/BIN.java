package fr.ensicaen.dserveur.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.NaturalId;

@Entity
@Table(name="bin")
public class BIN {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NaturalId
    private String bin_value;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBin_value() {
        return bin_value;
    }

    public void setBin_value(String bin_value) {
        this.bin_value = bin_value;
    }
}
