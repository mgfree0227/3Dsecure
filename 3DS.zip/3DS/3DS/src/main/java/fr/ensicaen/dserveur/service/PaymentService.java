package fr.ensicaen.dserveur.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class PaymentService {

    @Autowired
    private BinService binService;
    @Autowired
    private RestTemplate restTemplate;

    public void askFor3Dsecure(String pan) {

       // binService.saveData();

        List listBin = binService.getAll();

        String bin = pan.substring(1, 6);

        if (listBin.contains(bin)) {

        } else {
            callDirectoryServer(pan);
        }
    }
    public void callDirectoryServer(String pan){

        HttpEntity<String> request = new HttpEntity<>(pan);
        restTemplate.postForObject("http://localhost:8081/pan", request, String.class);
    }
    public void processConfirmation() {

    }
}
