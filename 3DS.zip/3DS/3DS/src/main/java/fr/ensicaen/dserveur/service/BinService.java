package fr.ensicaen.dserveur.service;

import fr.ensicaen.dserveur.entity.BIN;
import fr.ensicaen.dserveur.repository.BinRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BinService {

    @Autowired
    private BinRepository repository;

    public List<BIN> getAll() {
        return repository.findAll();
    }
    public void saveData(){
        BIN bin = new BIN();
        bin.setBin_value("458116");
        repository.save(bin);
    }
}
