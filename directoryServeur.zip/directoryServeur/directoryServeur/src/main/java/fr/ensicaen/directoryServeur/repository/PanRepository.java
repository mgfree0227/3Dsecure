package fr.ensicaen.directoryServeur.repository;

import fr.ensicaen.directoryServeur.entity.PAN;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PanRepository extends JpaRepository<PAN, Long> {
}
