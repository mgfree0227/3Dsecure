package fr.ensicaen.directoryServeur.service;

import fr.ensicaen.directoryServeur.entity.PAN;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import fr.ensicaen.directoryServeur.repository.PanRepository;

import java.util.List;

@Service
public class PanVerificationService {

    @Autowired
    private PanRepository repository;
    public boolean verifPan(String pan){
        List <PAN> listPAN = repository.findAll();

        if(listPAN.contains(pan))
        {
            return true;
        }
    return false;

    }
}
