package fr.ensicaen.dserveur.controller;

import fr.ensicaen.dserveur.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("payment")
public class PaymentController {

    @GetMapping("/hello")
     public String hello()
     {
        return "Hello word";
    }

    @Autowired
    private PaymentService service;

    @PostMapping("/process")
    public ResponseEntity<String> process(
            @RequestParam("amount") String amount,
            @RequestParam("pan") String pan) {
        System.out.println("amount="+amount);
        service.askFor3Dsecure(pan);
        return ResponseEntity.status(200).body("Hello");
    }

    @PostMapping("/confirmation")
    public String confirmation() {
        service.processConfirmation();
        return "";
    }
}
