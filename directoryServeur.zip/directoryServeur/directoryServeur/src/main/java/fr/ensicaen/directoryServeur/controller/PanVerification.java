package fr.ensicaen.directoryServeur.controller;

import fr.ensicaen.directoryServeur.service.PanVerificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("pan")
public class PanVerification {
    @Autowired
    private PanVerificationService verificationService;
    @PostMapping
    public void verifierPan(@RequestBody String pan){
            verificationService.verifPan(pan);
    }
}
