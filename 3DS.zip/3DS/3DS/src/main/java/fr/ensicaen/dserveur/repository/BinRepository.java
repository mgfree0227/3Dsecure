package fr.ensicaen.dserveur.repository;

import fr.ensicaen.dserveur.entity.BIN;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BinRepository extends JpaRepository<BIN, Long> {
}
