package fr.ensicaen.directoryServeur.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.NaturalId;

@Entity
@Table(name = "pan")
public class PAN {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;


    public String panValue;
}
