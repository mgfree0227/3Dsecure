package fr.ensicaen.directoryServeur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DirectoryServeurApplicationTests {

	@Test
	void contextLoads() {
	}

}
